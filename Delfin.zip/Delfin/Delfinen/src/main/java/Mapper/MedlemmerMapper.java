package Mapper;
public class MedlemmerMapper {

	public void TilføjMedlemmerTilDatabse() {
	}

	public void UpdaterMedlemmer() {
	}

}