package Mapper;
public class KontingentMapper {

	public void UpdaterKontingent() {
	}

	public void HentGæld() {
	}

}