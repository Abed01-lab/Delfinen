package Model;

public class System {

	public void opretMedlemmer() {
	}

	public void redigerMedlemmer() {
	}

	public void sekontingent() {		
	}

	public void registerKorder() {
	}

	public void hentResultater() {
	}

	public void tilføjStævne() {
	}

	public void SeTop5() {
	}

}