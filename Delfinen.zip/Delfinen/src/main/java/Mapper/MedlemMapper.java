package Mapper;

import Model.Medlem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MedlemMapper {

    Connection con = DatabaseConnector.getConnector();

    public void TilføjMedlemmerTilDatabse(Medlem medlem) {

        String prepareSQL = "INSERT INTO Svømmeklub.medlemmer (medlemmer.navn, medlemmer.alder, "
                + "medlemmer.tlf, medlemmer.adresse, medlemmer.status, medlemmer.aktivitetsform, medlemmer.kontingent, medlemmer.gæld) "
                + "VALUES (?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(prepareSQL);
            ps.setString(1, medlem.getNavn());
            ps.setInt(2, medlem.getAlder());
            ps.setInt(3, medlem.getTlf());
            ps.setString(4, medlem.getAdresse());
            ps.setInt(5, medlem.getStatus());
            ps.setString(6, medlem.getAktivitetsForm());
            ps.setInt(7, medlem.getKontingent());
            ps.setInt(8, medlem.getGæld());
            ps.execute();

        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ArrayList<Medlem> HentMedlemmerFraDatabase() {

        ArrayList<Medlem> MedlemsListe = new ArrayList<>();

        String excuteSQL = "SELECT medlemmer.id, medlemmer.navn, medlemmer.alder, medlemmer.tlf, "
                + "medlemmer.adresse, medlemmer.status, medlemmer.aktivitetsform "
                + "FROM Svømmeklub.medlemmer";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(excuteSQL);

            while (rs.next()) {
                int id = rs.getInt("id");
                String navn = rs.getString("navn");
                int alder = rs.getInt("alder");
                int tlf = rs.getInt("tlf");
                String adresse = rs.getString("adresse");
                int status = rs.getInt("status");
                String aktivitetsForm = rs.getString("aktivitetsform");

                Medlem medlem = new Medlem(id, navn, alder, tlf, adresse, status, aktivitetsForm);
                MedlemsListe.add(medlem);
            }

        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }

        return MedlemsListe;
    }

    public void UpdaterNavn(Medlem medlem, String navn) {
        String SQL = "UPDATE medlemmer SET navn = \"" + navn + "\" WHERE id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdaterAlder(Medlem medlem, int alder) {
        String SQL = "UPDATE medlemmer SET alder = " + alder + " WHERE id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdaterTlf(Medlem medlem, int tlf) {
        String SQL = "UPDATE medlemmer SET tlf = " + tlf + " WHERE id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdaterAdresse(Medlem medlem, String adresse) {
        String SQL = "UPDATE medlemmer SET adresse = \"" + adresse + "\" WHERE id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdaterStatus(Medlem medlem, int status) {
        String SQL = "UPDATE medlemmer SET status = " + status + " WHERE id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdaterAktivitetsForm(Medlem medlem, String aktivitetsForm) {
        String SQL = "UPDATE medlemmer SET aktivitetsform = \"" + aktivitetsForm + "\" WHERE id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
