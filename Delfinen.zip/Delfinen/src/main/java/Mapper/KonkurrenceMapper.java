package Mapper;

import Model.Medlem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class KonkurrenceMapper {

    Connection con = DatabaseConnector.getConnector();

    public ArrayList<Medlem> HentKunKonkurrenceMedlemmerFraDatabase() {

        ArrayList<Medlem> MedlemsListe = new ArrayList<>();

        String excuteSQL = "SELECT  medlemmer.id, medlemmer.navn, medlemmer.alder, medlemmer.tlf, medlemmer.adresse, medlemmer.status, medlemmer.aktivitetsform "
                + "FROM Svømmeklub.medlemmer "
                + "WHERE aktivitetsform = \"Konkurrencesvømmer\" AND status = 1";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(excuteSQL);

            while (rs.next()) {
                int id = rs.getInt("id");
                String navn = rs.getString("navn");
                int alder = rs.getInt("alder");
                int tlf = rs.getInt("tlf");
                String adresse = rs.getString("adresse");
                int status = rs.getInt("status");
                String aktivitetsForm = rs.getString("aktivitetsform");

                Medlem medlem = new Medlem(id, navn, alder, tlf, adresse, status, aktivitetsForm);
                MedlemsListe.add(medlem);
            }

        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }

        return MedlemsListe;
    }

    public void tilføjMedlemCrawl(Medlem medlem, int crawlPlacering, String crawlStævne, float crawlResultat) {

        String prepareSQL = "INSERT INTO svømmeklub.crawl (medlemmerid, crawl_placering, crawl_stævne, crawl_resultat)"
                + " VALUES (?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(prepareSQL);
            ps.setInt(1, medlem.getId());
            ps.setInt(2, crawlPlacering);
            ps.setString(3, crawlStævne);
            ps.setFloat(4, crawlResultat);
            ps.execute();

        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void tilføjMedlemButterfly(Medlem medlem, int butterflyPlacering, String butterflyStævne, float butterflyResultat) {
        String prepareSQL = "INSERT INTO svømmeklub.butterfly (medlemmerid, butterfly_placering, "
                + "butterfly_stævne, butterfly_resultat) VALUES (?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(prepareSQL);
            ps.setInt(1, medlem.getId());
            ps.setInt(2, butterflyPlacering);
            ps.setString(3, butterflyStævne);
            ps.setFloat(4, butterflyResultat);
            ps.execute();

        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void tilføjMedlemRygCrawl(Medlem medlem, int rygCrawlPlacering, String rygCrawlStævne, float rygCrawlResultat) {
        String prepareSQL = "INSERT INTO svømmeklub.rygcrawl (medlemmerid, rygcrawl_placering, rygcrawl_stævne, "
                + "rygcrawl_resultat) VALUES (?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(prepareSQL);
            ps.setInt(1, medlem.getId());
            ps.setInt(2, rygCrawlPlacering);
            ps.setString(3, rygCrawlStævne);
            ps.setFloat(4, rygCrawlResultat);
            ps.execute();

        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void tilføjMedlemBrystsvømning(Medlem medlem, int brystSvømningPlacering, String brystSvømningStævne, float brystSvømningResultat) {
        String prepareSQL = "INSERT INTO svømmeklub.brystsvømning (medlemmerid, brystsvømning_placering, brystsvømning_stævne, "
                + "brystsvømning_resultat) VALUES (?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(prepareSQL);
            ps.setInt(1, medlem.getId());
            ps.setInt(2, brystSvømningPlacering);
            ps.setString(3, brystSvømningStævne);
            ps.setFloat(4, brystSvømningResultat);
            ps.execute();

        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void seCrawlTop5() {
        String SQL = "SELECT crawl.medlemmerid, medlemmer.navn, crawl_stævne, crawl_resultat "
                + "FROM crawl, medlemmer "
                + "where medlemmerid = medlemmer.id and crawl_resultat > 0 "
                + "ORDER BY crawl_resultat "
                + "LIMIT 5";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                int id = rs.getInt("crawl.medlemmerid");
                String navn = rs.getString("medlemmer.navn");
                String stævne = rs.getString("crawl_stævne");
                float resultat = rs.getFloat("crawl_resultat");

                System.out.println(id + ", " + navn + ", " + stævne + ", Tid: " + resultat);

            }
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void seButterflyTop5() {
        String SQL = "SELECT butterfly.medlemmerid, medlemmer.navn, butterfly_stævne, butterfly_resultat "
                + "FROM butterfly, medlemmer "
                + "where medlemmerid = medlemmer.id and butterfly_resultat > 0 "
                + "ORDER BY butterfly_resultat "
                + "LIMIT 5";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                int id = rs.getInt("butterfly.medlemmerid");
                String navn = rs.getString("medlemmer.navn");
                String stævne = rs.getString("butterfly_stævne");
                float resultat = rs.getFloat("butterfly_resultat");

                System.out.println(id + ", " + navn + ", " + stævne + ", Tid: " + resultat);

            }
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void seRygCrawlTop5() {
        String SQL = "SELECT rygcrawl.medlemmerid, medlemmer.navn, rygcrawl_stævne, rygcrawl_resultat "
                + "FROM rygcrawl, medlemmer "
                + "where medlemmerid = medlemmer.id and rygcrawl_resultat > 0 "
                + "ORDER BY rygcrawl_resultat "
                + "LIMIT 5";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                int id = rs.getInt("rygcrawl.medlemmerid");
                String navn = rs.getString("medlemmer.navn");
                String stævne = rs.getString("rygcrawl_stævne");
                float resultat = rs.getFloat("rygcrawl_resultat");

                System.out.println(id + ", " + navn + ", " + stævne + ", Tid: " + resultat);

            }
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void seBrystSvømnigTop5() {
        String SQL = "SELECT brystsvømning.medlemmerid, medlemmer.navn, brystsvømning_stævne, brystsvømning_resultat "
                + "FROM brystsvømning, medlemmer "
                + "where medlemmerid = medlemmer.id and brystsvømning_resultat > 0 "
                + "ORDER BY brystsvømning_resultat "
                + "LIMIT 5";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                int id = rs.getInt("brystsvømning.medlemmerid");
                String navn = rs.getString("medlemmer.navn");
                String stævne = rs.getString("brystsvømning_stævne");
                float resultat = rs.getFloat("brystsvømning_resultat");

                System.out.println(id + ", " + navn + ", " + stævne + ", Tid: " + resultat);

            }
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void seCrawl() {
        String SQL = "SELECT crawl.medlemmerid, medlemmer.navn, crawl_stævne, crawl_resultat "
                + "FROM crawl, medlemmer "
                + "where medlemmerid = medlemmer.id";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                int id = rs.getInt("crawl.medlemmerid");
                String navn = rs.getString("medlemmer.navn");
                String stævne = rs.getString("crawl_stævne");
                float resultat = rs.getFloat("crawl_resultat");

                System.out.println(id + ", " + navn + ", " + stævne + ", Tid: " + resultat);

            }
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void seButterfly() {
        String SQL = "SELECT butterfly.medlemmerid, medlemmer.navn, butterfly_stævne, butterfly_resultat "
                + "FROM butterfly, medlemmer "
                + "where medlemmerid = medlemmer.id";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                int id = rs.getInt("butterfly.medlemmerid");
                String navn = rs.getString("medlemmer.navn");
                String stævne = rs.getString("butterfly_stævne");
                float resultat = rs.getFloat("butterfly_resultat");

                System.out.println(id + ", " + navn + ", " + stævne + ", Tid: " + resultat);

            }
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void seRygCrawl() {
        String SQL = "SELECT rygcrawl.medlemmerid, medlemmer.navn, rygcrawl_stævne, rygcrawl_resultat "
                + "FROM rygcrawl, medlemmer "
                + "where medlemmerid = medlemmer.id";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                int id = rs.getInt("rygcrawl.medlemmerid");
                String navn = rs.getString("medlemmer.navn");
                String stævne = rs.getString("rygcrawl_stævne");
                float resultat = rs.getFloat("rygcrawl_resultat");

                System.out.println(id + ", " + navn + ", " + stævne + ", Tid: " + resultat);

            }
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void seBrystSvømnig() {
        String SQL = "SELECT brystsvømning.medlemmerid, medlemmer.navn, brystsvømning_stævne, brystsvømning_resultat "
                + "FROM brystsvømning, medlemmer "
                + "where medlemmerid = medlemmer.id";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                int id = rs.getInt("brystsvømning.medlemmerid");
                String navn = rs.getString("medlemmer.navn");
                String stævne = rs.getString("brystsvømning_stævne");
                float resultat = rs.getFloat("brystsvømning_resultat");

                System.out.println(id + ", " + navn + ", " + stævne + ", Tid: " + resultat);

            }
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdaterBestTidCrawl(Medlem medlem, float resultat) {
        String SQL = "UPDATE medlemmer SET crawl_besttid = " + resultat + " WHERE id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdaterBestTidRygCrawl(Medlem medlem, float resultat) {
        String SQL = "UPDATE medlemmer SET rygcrawl_besttid = " + resultat + " WHERE id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdaterBestBrystSvømning(Medlem medlem, float resultat) {
        String SQL = "UPDATE medlemmer SET brystsvømning_besttid = " + resultat + " WHERE id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void UpdaterBestButterfly(Medlem medlem, float resultat) {
        String SQL = "UPDATE medlemmer SET butterfly_besttid = " + resultat + " WHERE id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapper.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
