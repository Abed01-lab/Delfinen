package Mapper;

import Model.Medlem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class KontingentMapper {

    Connection con = DatabaseConnector.getConnector();

    public void printMedlemmersKontingentOgGæld() {
        String excuteSQL = "SELECT medlemmer.id, medlemmer.navn, medlemmer.kontingent, medlemmer.gæld"
                + " FROM Medlemmer";

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(excuteSQL);

            while (rs.next()) {
                int id = rs.getInt("id");
                String navn = rs.getString("navn");
                int kontingent = rs.getInt("kontingent");
                int gæld = rs.getInt("gæld");
                
                System.out.println(id + ", " + navn + ", Kontingent: " + kontingent + " Kr, Restance" + gæld + " kr.");
            }

        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updaterGæld(Medlem medlem, int gæld) {
        String SQL = "UPDATE medlemmer SET gæld = gæld + " + gæld + " Where id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void updaterKontingent(Medlem medlem, int kontingent) {
        String SQL = "UPDATE medlemmer SET kontingent = " + kontingent + " Where id = " + medlem.getId();
        try {
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
