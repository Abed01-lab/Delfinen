package Model;

import Mapper.MedlemMapper;
import Mapper.KontingentMapper;
import java.util.Random;

public class Kontingent {

    Random random = new Random();
    MedlemMapper mm = new MedlemMapper();
    KontingentMapper km = new KontingentMapper();
    
    public void sendRegninger() {
        for(Medlem medlem: mm.HentMedlemmerFraDatabase()){
            int randomnr = random.nextInt(2);
            if (randomnr != 1){
                km.updaterGæld(medlem, medlem.getKontingent());
            }
        }
    }

}
