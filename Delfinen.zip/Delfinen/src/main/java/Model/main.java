package Model;

public class main {
    public static void main(String[] args) {
            Excuter system = new Excuter();
            system.kør();
    }
}
