package Model;

public class Medlem {

    private int id;

    private String navn;
    private int alder;
    private int tlf;
    private String adresse;
    private int status;
    private String sStatus;
    private String aktivitetsForm;
    private int kontingent;
    private int gæld;

    public Medlem(String navn, int alder, int tlf, String adresse, int status, String aktivitetsForm) {
        this.navn = navn;
        this.alder = alder;
        this.tlf = tlf;
        this.adresse = adresse;
        this.status = status;
        this.aktivitetsForm = aktivitetsForm;
        udregnKontingent(alder);
    }
    
    public Medlem(int id, String navn, int alder, int tlf, String adresse, int status, String aktivitetsForm) {
        this.id = id;
        this.navn = navn;
        this.alder = alder;
        this.tlf = tlf;
        this.adresse = adresse;
        this.status = status;
        this.aktivitetsForm = aktivitetsForm;
        udregnKontingent(alder);
        status(status);
    }

    public int getId() {
        return id;
    }
    
    public String getNavn() {
        return this.navn;
    }

    public void setNavn(String navn) {
        this.navn = navn;
    }

    public int getAlder() {
        return this.alder;
    }

    public void setAlder(int alder) {
        this.alder = alder;
    }

    public int getTlf() {
        return this.tlf;
    }

    public void setTlf(int tlf) {
        this.tlf = tlf;
    }

    public String getAdresse() {
        return this.adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public int getStatus() {
        return this.status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getAktivitetsForm() {
        return aktivitetsForm;
    }

    public void setAktivitetsForm(String aktivitetsForm) {
        this.aktivitetsForm = aktivitetsForm;
    }

    public int getKontingent() {
        return this.kontingent;
    }

    public void setKontingent(int kontingent) {
        this.kontingent = kontingent;
    }

    public int getGæld() {
        return this.gæld;
    }

    public void setGæld(int gæld) {
        this.gæld = gæld;
    }
    
    private void udregnKontingent(int alder) {

        if (alder < 18 && status == 1) {
            this.kontingent = 1000;
        } else if (alder >= 18 && alder < 60 && status == 1) {
            this.kontingent = 1600;
        }else if (alder >= 60 && status == 1){
            this.kontingent = 1200;
        }else {
            this.kontingent = 500;
        }
    }
    
    private void status(int status){
        if (status == 1) {
            sStatus = "Aktivt";
        } else{
            sStatus = "Passivt";
        }
    }

    @Override
    public String toString() {
        return navn + ", " + alder + ", " + tlf + ", " + adresse + ", " + sStatus + ", " + aktivitetsForm;
    }
    
    

}
