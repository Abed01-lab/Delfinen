package Model;

public interface Menu {

    public void startsSkærm();

}
