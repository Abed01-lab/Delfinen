package Model;

import Mapper.KonkurrenceMapper;
import Mapper.KontingentMapper;
import Mapper.MedlemMapper;
import java.util.Scanner;

public class Excuter implements Menu {

    Scanner input = new Scanner(System.in);
    MedlemMapper mm = new MedlemMapper();
    Kontingent kt = new Kontingent();
    KontingentMapper km = new KontingentMapper();
    KonkurrenceMapper kkm = new KonkurrenceMapper();

    boolean kør = true;

    public void kør() {

        while (true) {
            startsSkærm();

            validering();
            switch (input.nextInt()) {
                case 1:
                    opretMedlemmer();
                    break;
                case 2:
                    redigerMedlemmer();
                    break;
                case 3:
                    sekontingent();
                    break;
                case 4:
                    konkurrence();
                    break;

                default:
                    System.out.println("Uglydigt tegn!");
            }
        }
    }

    @Override
    public void startsSkærm() {
        System.out.println("\nVelkommen til Sytemet");
        System.out.println("Vælg mellem følgende:"
                + "\n1. Opret Medlemmer"
                + "\n2. Rediger Medlemmer"
                + "\n3. Se Kontingent"
                + "\n4. Konkurrence");
    }

    private void opretMedlemmer() {
        System.out.println("\nIndtast Navn");
        String navn = input.next();

        while (!navn.matches("[a-zA-Z,]+")) {
            System.out.println("Ugyldig Tegn");
            navn = input.next();
        }

        System.out.println("Indtast alder");

        validering();
        int alder = input.nextInt();

        while (alder <= 0 || alder > 150) {
            System.out.println("Ugyldig Tegn");
            alder = input.nextInt();
        }

        System.out.println("Indtast telefon nr");
        validering();
        int tlf = input.nextInt();

        while (tlf < 10000000 || tlf > 99999999) {
            System.out.println("Ugyldig Tegn");
            tlf = input.nextInt();
        }

        System.out.println("Indtast adresse");
        String adresse = input.next();
        adresse += " " + input.nextLine();

        System.out.println("Indtast status (1 for aktiv, 0 for passivt)");
        validering();
        int status = input.nextInt();

        while (status > 1 || status < 0) {
            System.out.println("Ugyldig Tegn");
            status = input.nextInt();
        }

        System.out.println("Indtast aktivitetsform (1 for motionist, 0 for kunkurrencesvømmer)");
        validering();
        int CCaktivitetsForm = input.nextInt();

        while (CCaktivitetsForm > 1 || CCaktivitetsForm < 0) {
            System.out.println("Ugyldig Tegn");
            CCaktivitetsForm = input.nextInt();
        }

        String aktivitetsForm = "";
        if (CCaktivitetsForm == 1) {
            aktivitetsForm = "Motionist";
        } else {
            aktivitetsForm = "Konkurrencesvømmer";
        }

        Medlem medlem = new Medlem(navn, alder, tlf, adresse, status, aktivitetsForm);
        mm.TilføjMedlemmerTilDatabse(medlem);

        System.out.println("Medlem Registeret!\n");
    }

    private void redigerMedlemmer() {
        int counter = 0;
        boolean skalBliveVed = true;

        System.out.println("\n");
        for (Medlem medlem : mm.HentMedlemmerFraDatabase()) {
            counter++;
            System.out.println(counter + ", " + medlem.toString());
        }
        System.out.println("Vælg hvilken medlem du vil redigere på");
        validering();
        int medlemid = input.nextInt();

        while (medlemid > mm.HentMedlemmerFraDatabase().size() + 1) {
            System.out.println("Ugyldig Tegn");
            input.next();
        }

        while (skalBliveVed) {
            System.out.println("\nVælg mellem følgende:"
                    + "\n1. Rediger Navn"
                    + "\n2. Rediger Alder"
                    + "\n3. Rediger Tfl"
                    + "\n4. Rediger Adresse"
                    + "\n5. Rediger Status"
                    + "\n6. Rediger Aktivitetsform"
                    + "\n0. For at gå tilbage");

            validering();
            switch (input.nextInt()) {
                case 1:
                    System.out.println("Indtatst det nye navn...");
                    String navn = input.next();

                    while (!navn.matches("[a-zA-Z,]+")) {
                        System.out.println("Ugyldig Tegn");
                        navn = input.next();
                    }

                    mm.UpdaterNavn(mm.HentMedlemmerFraDatabase().get(medlemid - 1), navn);
                    break;

                case 2:
                    System.out.println("Indtatst den nye alder...");
                    validering();
                    int alder = input.nextInt();

                    while (alder <= 0 || alder > 150) {
                        System.out.println("Ugyldig Tegn");
                        alder = input.nextInt();
                    }

                    mm.UpdaterAlder(mm.HentMedlemmerFraDatabase().get(medlemid - 1), alder);
                    km.updaterKontingent(mm.HentMedlemmerFraDatabase().get(medlemid - 1), mm.HentMedlemmerFraDatabase().get(medlemid - 1).getKontingent());
                    break;

                case 3:
                    System.out.println("Indtatst det nye tfl...");
                    validering();
                    int tlf = input.nextInt();

                    while (tlf < 10000000 || tlf > 99999999) {
                        System.out.println("Ugyldig Tegn");
                        tlf = input.nextInt();
                    }

                    mm.UpdaterTlf(mm.HentMedlemmerFraDatabase().get(medlemid - 1), tlf);
                    break;

                case 4:
                    System.out.println("Indtatst den nye adresse...");
                    String adresse = input.next();
                    adresse += " " + input.nextLine();
                    mm.UpdaterAdresse(mm.HentMedlemmerFraDatabase().get(medlemid - 1), adresse);
                    break;

                case 5:
                    System.out.println("Indtatst det nye status (1  for aktiv, 0 for passivt...)");
                    validering();
                    int status = input.nextInt();

                    while (status > 1 || status < 0) {
                        System.out.println("Ugyldig Tegn");
                        status = input.nextInt();
                    }

                    mm.UpdaterStatus(mm.HentMedlemmerFraDatabase().get(medlemid - 1), status);
                    km.updaterKontingent(mm.HentMedlemmerFraDatabase().get(medlemid - 1), mm.HentMedlemmerFraDatabase().get(medlemid - 1).getKontingent());
                    break;

                case 6:
                    System.out.println("Indtatst det nye aktivitetsform (1  for Motionist, 0 for Konkurrencesvømmer)...");
                    validering();
                    int CCaktivitetsForm = input.nextInt();

                    while (CCaktivitetsForm > 1 || CCaktivitetsForm < 0) {
                        System.out.println("Ugyldig Tegn");
                        CCaktivitetsForm = input.nextInt();
                    }

                    String aktivitetsForm = "";
                    if (CCaktivitetsForm == 1) {
                        aktivitetsForm = "Motionist";
                    } else {
                        aktivitetsForm = "Konkurrencesvømmer";
                    }
                    mm.UpdaterAktivitetsForm(mm.HentMedlemmerFraDatabase().get(medlemid - 1), aktivitetsForm);
                    break;

                case 0:
                    skalBliveVed = false;
                    break;

                default:
                    System.out.println("Uglydigt tegn!");
            }

            System.out.println("Vil du ændre mere på denne medlem? "
                    + "\n1. for ja"
                    + "\n2. for nej");

            int nr = input.nextInt();
            if (nr != 1) {
                skalBliveVed = false;
            }
        }

    }

    private void sekontingent() {
        boolean skalBliveVed = true;

        while (skalBliveVed) {
            System.out.println("\nVælg mellem følgende:"
                    + "\n1. Send Regninger"
                    + "\n2. Se medlemmer i restance"
                    + "\n0. For at gå tilbage");
            validering();
            switch (input.nextInt()) {
                case 1:
                    kt.sendRegninger();
                    System.out.println("Regninger sendt");
                    break;
                case 2:
                    km.printMedlemmersKontingentOgGæld();
                    break;
                case 0:
                    skalBliveVed = false;
                    break;

                default:
                    System.out.println("Uglydigt tegn!");

            }
        }
    }

    private void konkurrence() {
        boolean skalBliveVed = true;

        while (skalBliveVed) {
            System.out.println("\nVælg mellem følgende:"
                    + "\n1. Registere rekorder"
                    + "\n2. Se resultater"
                    + "\n3. Se Top 5"
                    + "\n0. For at gå tilbage");

            validering();
            switch (input.nextInt()) {
                case 1:
                    registereRekorder();
                    break;
                case 2:
                    seResultater();
                    break;
                case 3:
                    SeTop5();
                    break;
                case 0:
                    skalBliveVed = false;
                    break;

                default:
                    System.out.println("Uglydigt tegn!");
            }
        }

    }

    private void registereRekorder() {

        boolean skalBliveVed = true;

        while (skalBliveVed) {
            int counter = 0;
            System.out.println("\nVælg diciplin:"
                    + "\n1. Brystsvømning"
                    + "\n2. Butterfly"
                    + "\n3. Crawl"
                    + "\n4. Rygcrawl"
                    + "\n0. For at gå tilbage"
                    + "\n");

            validering();
            int diciplin = input.nextInt();

            for (Medlem medlem : kkm.HentKunKonkurrenceMedlemmerFraDatabase()) {
                counter++;
                System.out.println(counter + ", " + medlem.toString());
            }

            System.out.println("\nVælg medlem");
            validering();
            int nr = input.nextInt();

            while (nr > kkm.HentKunKonkurrenceMedlemmerFraDatabase().size() + 1) {
                System.out.println("Ugyldig Tegn");
                input.next();
            }

            System.out.println("Hvilken stævne");
            String stævne = input.next();
            stævne += " " + input.nextLine();

            System.out.println("Hvilken placering");
            validering();
            int placering = input.nextInt();

            System.out.println("Hvilken tid");
            while (!input.hasNextFloat()) {
                System.out.println("Ugyldig Tegn");
                input.next();
            }
            float tid = input.nextFloat();

            switch (diciplin) {
                case 1:
                    kkm.tilføjMedlemBrystsvømning(kkm.HentKunKonkurrenceMedlemmerFraDatabase().get(nr - 1), placering, stævne, tid);
                    break;
                case 2:
                    kkm.tilføjMedlemButterfly(kkm.HentKunKonkurrenceMedlemmerFraDatabase().get(nr - 1), placering, stævne, tid);
                    break;
                case 3:
                    kkm.tilføjMedlemCrawl(kkm.HentKunKonkurrenceMedlemmerFraDatabase().get(nr - 1), placering, stævne, tid);
                    break;
                case 4:
                    kkm.tilføjMedlemRygCrawl(kkm.HentKunKonkurrenceMedlemmerFraDatabase().get(nr - 1), placering, stævne, tid);
                    break;

                default:
                    System.out.println("Uglydigt tegn!");
            }
        }
    }

    private void seResultater() {
        boolean skalBliveVed = true;

        while (skalBliveVed) {
            System.out.println("\nVælg hvilken diciplin du vil se"
                    + "\n1. Brystsvømning"
                    + "\n2. Butterfly"
                    + "\n3. Crawl"
                    + "\n4. Rygcrawl"
                    + "\n0. For at gå tilbage");

            validering();
            switch (input.nextInt()) {
                case 1:
                    kkm.seBrystSvømnig();
                    break;
                case 2:
                    kkm.seButterfly();
                    break;
                case 3:
                    kkm.seCrawl();
                    break;
                case 4:
                    kkm.seRygCrawl();
                    break;
                case 0:
                    skalBliveVed = false;
                    break;

                default:
                    System.out.println("Uglydigt tegn!");
            }
        }
    }

    private void SeTop5() {
        boolean skalBliveVed = true;

        while (skalBliveVed) {
            System.out.println("\nVælg hvilken diciplin du vil se"
                    + "\n1. Brystsvømning"
                    + "\n2. Butterfly"
                    + "\n3. Crawl"
                    + "\n4. Rygcrawl"
                    + "\n0. For at gå tilbage");
            validering();
            switch (input.nextInt()) {
                case 1:
                    kkm.seBrystSvømnigTop5();
                    break;
                case 2:
                    kkm.seButterflyTop5();
                    break;
                case 3:
                    kkm.seCrawlTop5();
                    break;
                case 4:
                    kkm.seRygCrawlTop5();
                    break;
                case 0:
                    skalBliveVed = false;
                    break;
            }
        }
    }

    private void validering() {
        while (!input.hasNextInt()) {
            System.out.println("Ugyldig Tegn");
            input.next();
        }
    }

}
