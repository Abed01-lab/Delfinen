package ModelTest;

import Mapper.DatabaseConnector;
import Model.Medlem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Test;
import static org.junit.Assert.*;


public class KonkurrenceMapperTest {
    
    @Test
    public void TilføjMedlemTilCrawlTest() {
        Medlem abed = new Medlem(1, "Abed", 22, 25707013, "Belvederevej 4C, 3000 Helsingør", 1, "Motionist");
        int expectedcrawlPlacering = 1;
        String expectedcrawlStævne = "VM";
        float expectedcrawlResultat = 10.6f;
        
        int id = 0;
        int placering = 0;
        String crawlStævne = "";
        float crawlResultat = 0;                   
        
        String prepareSQL = "INSERT INTO svømmeklub.crawl (medlemmerid, crawl_placering, crawl_stævne, crawl_resultat)"
                + " VALUES (?,?,?,?)";
        try {
            Connection con = DatabaseConnector.getConnector();
            PreparedStatement ps = con.prepareStatement(prepareSQL);
            ps.setInt(1, abed.getId());
            ps.setInt(2, expectedcrawlPlacering);
            ps.setString(3, expectedcrawlStævne);
            ps.setFloat(4, expectedcrawlResultat);
            ps.execute();

        } catch (SQLException ex) {
            Logger.getLogger(KonkurrenceMapperTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String excuteSQL = "SELECT crawl.id, crawl.medlemmerid, crawl.crawl_placering, crawl.crawl_stævne, "
                + "crawl.crawl_resultat FROM crawl WHERE crawl.medlemmerid = 1 and crawl.id = 1"; 
        try {
            Connection con = DatabaseConnector.getConnector();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(excuteSQL);
            while (rs.next()) {
                
                id = rs.getInt("medlemmerid");            
                placering = rs.getInt("crawl_placering");
                crawlStævne = rs.getString("crawl_stævne");
                crawlResultat = rs.getFloat("crawl_resultat");

            }

            assertEquals(abed.getId(), id);;
            assertEquals(expectedcrawlPlacering, placering);
            assertEquals(expectedcrawlStævne, crawlStævne);
            assertEquals(expectedcrawlResultat, crawlResultat, 0.0f);
            

        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapperTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }
    
}