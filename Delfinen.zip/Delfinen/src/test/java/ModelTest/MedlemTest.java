package ModelTest;



import org.junit.Test;
import static org.junit.Assert.*;
import Model.Medlem;


public class MedlemTest {
    
    @Test
    public void MedlemTest() {
        Medlem abed = new Medlem("Abed", 22, 25707013, "Belvederevej 4C, 3000 Helsingør", 1, "Motionist" );
        
        assertEquals(abed, abed);
    }
    
}
