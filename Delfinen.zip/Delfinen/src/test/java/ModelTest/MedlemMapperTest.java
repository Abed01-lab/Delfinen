package ModelTest;

import Mapper.DatabaseConnector;
import Mapper.MedlemMapper;
import Model.Medlem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Test;
import static org.junit.Assert.*;

public class MedlemMapperTest {

    @Test
    public void TilføjMedlemmerTilDatabseTest() {
        Medlem abed = new Medlem("Abed", 22, 25707013, "Belvederevej 4C, 3000 Helsingør", 1, "Motionist");

        String prepareSQL = "INSERT INTO Svømmeklub.medlemmer (medlemmer.id, medlemmer.navn, medlemmer.alder, medlemmer.tlf, "
                + "medlemmer.adresse, medlemmer.status, medlemmer.aktivitetsform) VALUES (?,?,?,?,?,?,?)";

        String excuteSQL = "SELECT medlemmer.id, medlemmer.navn, medlemmer.alder, medlemmer.tlf, medlemmer.adresse, "
                + "medlemmer.status, medlemmer.aktivitetsform FROM Svømmeklub.medlemmer "
                + "Where medlemmer.id = 1 and medlemmer.navn = \"Abed\"and medlemmer.alder = 22 and medlemmer.tlf = 25707013 "
                + "and medlemmer.adresse = \"Belvederevej 4C, 3000 Helsingør\" and medlemmer.status = 1 "
                + "and medlemmer.aktivitetsform  = \"Motionist\" ";

        try {
            Connection con = DatabaseConnector.getConnector();
            PreparedStatement ps = con.prepareStatement(prepareSQL);
            ps.setInt(1, abed.getId());
            ps.setString(2, abed.getNavn());
            ps.setInt(3, abed.getAlder());
            ps.setInt(4, abed.getTlf());
            ps.setString(5, abed.getAdresse());
            ps.setInt(6, abed.getStatus());
            ps.setString(7, abed.getAktivitetsForm());
            ps.execute();

        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapperTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        String navn = "";
        int alder = 0;
        int tlf = 0;
        String adresse = "";
        int status = 0;
        String aktivitetsForm = "";

        String expNavn = "Abed";
        int expAlder = 22;
        int expTlf = 25707013;
        String expAdresse = "Belvederevej 4C, 3000 Helsingør";
        int expStatus = 1;
        String expAktivitetsForm = "Motionist";

        try {
            Connection con = DatabaseConnector.getConnector();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(excuteSQL);
            while (rs.next()) {

                navn = rs.getString("navn");
                alder = rs.getInt("alder");
                tlf = rs.getInt("tlf");
                adresse = rs.getString("adresse");
                status = rs.getInt("status");
                aktivitetsForm = rs.getString("aktivitetsform");
            }

            assertEquals(expNavn, navn);
            assertEquals(expAlder, alder);
            assertEquals(expTlf, tlf);
            assertEquals(expAdresse, adresse);
            assertEquals(expStatus, status);
            assertEquals(expAktivitetsForm, aktivitetsForm);

        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapperTest.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Test
    public void UpdaterTest() {
        String expectednavn = "hej";
        String navn = "";
        String SQL = "UPDATE medlemmer SET navn = \"" + expectednavn + "\" WHERE id = 1";
        String PreparedSQL = "select medlemmer.navn from medlemmer where medlemmer.id = 1";
        try {
            Connection con = DatabaseConnector.getConnector();
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapper.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            Connection con = DatabaseConnector.getConnector();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(PreparedSQL);
            while (rs.next()) {

                navn = rs.getString("navn");
            }
            
            assertEquals(expectednavn, navn);
        } catch (SQLException ex) {
            Logger.getLogger(MedlemMapperTest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
